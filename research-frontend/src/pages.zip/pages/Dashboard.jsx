import { useState } from "react";
import SearchBar from "../components/SearchBar";
import PublicationTable from "../components/PublicationTable";
import "../App.css";

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable"; // ✅ correct import

function Dashboard() {
  const [data, setData] = useState([]);

  // ✅ PDF Download Function (Fixed)
  const downloadPDF = () => {
    console.log("Download button clicked"); // debug

    const doc = new jsPDF();

    // Title
    doc.setFontSize(18);
    doc.text("Research Portfolio Report", 20, 15);

    // If no data
    if (!data || data.length === 0) {
      doc.setFontSize(12);
      doc.text("No publications available", 20, 30);
    } else {
      const tableData = data.map((item, index) => [
        index + 1,
        item,
      ]);

      // ✅ Correct way to use autoTable
      autoTable(doc, {
        head: [["No", "Title"]],
        body: tableData,
        startY: 25,
      });
    }

    // Save file
    doc.save("research_data.pdf");
  };

  return (
    <div className="dashboard">

      {/* Title */}
      <div className="title">
        <h1>Research Portfolio Dashboard</h1>
      </div>

      {/* Card */}
      <div className="card">
        <SearchBar setData={setData} />

        {/* Table */}
        <PublicationTable data={data} />

        {/* Download Button */}
        <button className="download-btn" onClick={downloadPDF}>
          Download PDF
        </button>
      </div>

    </div>
  );
}

export default Dashboard;